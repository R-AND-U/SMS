package com.sms.enums;


public enum VacationStatus {
    PENDING,
    APPROVED,
    REJECTED
}
