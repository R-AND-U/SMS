package com.sms.enums;


public enum Gender {
    MALE, FEMALE
}
