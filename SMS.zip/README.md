# SMS
A large project for a course on program design, themed ‘Student Management System’, based on Java 25 + Javafx 25 + SpringBoot 4.0.0.